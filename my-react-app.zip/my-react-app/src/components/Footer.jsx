export default function Footer() {
  return (
    <footer>
      <p className="text-xl font-semibold text-blue-400">
        ECMA - WD20307 là đơn vị cung cấp dịch vụ du lịch lữ hành Quốc tế,
        chuyên thị trường Mỹ, Canada, Châu Âu, Úc, Singapore - Malaysia, Thái
        Lan cũng như chuyên Du lịch MICE - Tổ chức Event - TeamBuilding - Gala
        Dinner
      </p>
    </footer>
  )
}