// title= Tour Nội Địa
// in dam, viet hoa, mau xanh, co border o duoi
export default function Heading(){
    return (
        <h1 className="font-bold uppercase text-blue-600 border-b-2 border-blue-600 pb-2 text-2xl">
            Tour Nội Địa
        </h1>
    )
}