// src/pages/About.jsx

function About() {
  return (
    <main className="text-center py-20">
      <h1>Đây là Trang Giới Thiệu</h1>
    </main>
  );
}

export default About;